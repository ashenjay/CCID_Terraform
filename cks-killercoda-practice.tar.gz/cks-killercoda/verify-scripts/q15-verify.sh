#!/bin/bash
echo "=== Q15 Verification ==="
PASS=true

APISERVER="/etc/kubernetes/manifests/kube-apiserver.yaml"

echo -n "[1] ImagePolicyWebhook in admission plugins: "
if grep -q 'ImagePolicyWebhook' $APISERVER; then echo "PASS ✅"; else echo "FAIL ❌"; PASS=false; fi

echo -n "[2] admission-control-config-file flag set: "
if grep -q 'admission-control-config-file' $APISERVER; then echo "PASS ✅"; else echo "FAIL ❌"; PASS=false; fi

echo -n "[3] defaultAllow=false in image-policy-config.yaml: "
if grep -q 'defaultAllow: false' /etc/kubernetes/epconfig/image-policy-config.yaml 2>/dev/null; then
  echo "PASS ✅"
else echo "FAIL ❌"; PASS=false; fi

echo -n "[4] defaultAllow=false in admission-config.yaml: "
if grep -q 'defaultAllow: false' /etc/kubernetes/epconfig/admission-config.yaml 2>/dev/null; then
  echo "PASS ✅"
else echo "WARN ⚠️ (also update admission-config.yaml)"; fi

echo -n "[5] Webhook server URL set in kube-config.yaml: "
if grep -q 'image-bouncer-webhook.default.svc:1323/image_policy' /etc/kubernetes/epconfig/kube-config.yaml 2>/dev/null; then
  echo "PASS ✅"
else echo "FAIL ❌"; PASS=false; fi

echo -n "[6] kube-apiserver running: "
if kubectl -n kube-system get pod -l component=kube-apiserver 2>/dev/null | grep -q Running; then
  echo "PASS ✅"
else echo "WARN ⚠️ (may need a few minutes to restart)"; fi

echo ""
if $PASS; then echo "✅ Q15 ALL CHECKS PASSED"; else echo "❌ Q15 SOME CHECKS FAILED"; fi
