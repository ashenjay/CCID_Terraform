#!/bin/bash
echo "=== Q4 Verification ==="
PASS=true

echo -n "[1] Deployment 'cpu' scaled to 0: "
REPLICAS=$(kubectl get deployment cpu -o jsonpath='{.spec.replicas}' 2>/dev/null)
if [ "$REPLICAS" = "0" ]; then
  echo "PASS ✅"
else
  echo "FAIL ❌ (replicas=$REPLICAS)"; PASS=false
fi

echo -n "[2] Deployment 'web' still running: "
if kubectl get deployment web 2>/dev/null | grep -q '1/1'; then
  echo "PASS ✅"
else
  echo "WARN ⚠️"
fi

echo -n "[3] Deployment 'api' still running: "
if kubectl get deployment api 2>/dev/null | grep -q '1/1'; then
  echo "PASS ✅"
else
  echo "WARN ⚠️"
fi

echo -n "[4] Falco rules file exists: "
if [ -s /etc/falco/falco_rules.local.yaml ]; then
  echo "PASS ✅"
else
  echo "WARN ⚠️ (empty or missing)"
fi

echo ""
if $PASS; then echo "✅ Q4 ALL CHECKS PASSED"; else echo "❌ Q4 SOME CHECKS FAILED"; fi
