#!/bin/bash
echo "=== Q11 Verification ==="
PASS=true

echo -n "[1] ~/alpine.spdx exists: "
if [ -f ~/alpine.spdx ]; then echo "PASS ✅"; else echo "FAIL ❌"; PASS=false; fi

echo -n "[2] Deployment has only 2 containers (alpine-b removed): "
COUNT=$(kubectl -n alpine get deployment alpine -o jsonpath='{.spec.template.spec.containers[*].name}' 2>/dev/null | wc -w)
if [ "$COUNT" = "2" ]; then echo "PASS ✅"; else echo "FAIL ❌ (found $COUNT containers)"; PASS=false; fi

echo -n "[3] alpine-a still exists: "
kubectl -n alpine get deployment alpine -o yaml 2>/dev/null | grep -q 'alpine-a' && echo "PASS ✅" || { echo "FAIL ❌"; PASS=false; }

echo -n "[4] alpine-c still exists: "
kubectl -n alpine get deployment alpine -o yaml 2>/dev/null | grep -q 'alpine-c' && echo "PASS ✅" || { echo "FAIL ❌"; PASS=false; }

echo ""
if $PASS; then echo "✅ Q11 ALL CHECKS PASSED"; else echo "❌ Q11 SOME CHECKS FAILED"; fi
