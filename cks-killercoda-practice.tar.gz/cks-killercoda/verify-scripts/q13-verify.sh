#!/bin/bash
echo "=== Q13 Verification ==="
PASS=true

echo -n "[1] developer NOT in docker group: "
if id developer 2>/dev/null | grep -qv 'docker'; then echo "PASS ✅"
elif ! id developer &>/dev/null; then echo "SKIP (user doesn't exist)"
else echo "FAIL ❌"; PASS=false; fi

echo -n "[2] docker.socket SocketGroup=root: "
if grep -q 'SocketGroup=root' /usr/lib/systemd/system/docker.socket 2>/dev/null; then
  echo "PASS ✅"
else echo "FAIL ❌"; PASS=false; fi

echo -n "[3] docker.service has no TCP listener: "
if ! grep -q 'tcp://' /usr/lib/systemd/system/docker.service 2>/dev/null; then
  echo "PASS ✅"
else echo "FAIL ❌ (still has tcp:// in ExecStart)"; PASS=false; fi

echo ""
if $PASS; then echo "✅ Q13 ALL CHECKS PASSED"; else echo "❌ Q13 SOME CHECKS FAILED"; fi
