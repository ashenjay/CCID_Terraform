#!/bin/bash
echo "=== Q10 Verification ==="
echo "On single-node Killercoda, verify knowledge:"
echo ""
kubectl get nodes
echo ""
echo "Key commands to memorize:"
echo "  apt install kubelet=X.Y.Z-1.1 kubeadm=X.Y.Z-1.1 kubectl=X.Y.Z-1.1"
echo "  systemctl daemon-reload && systemctl restart kubelet"
echo ""
echo "✅ Q10: Review complete (knowledge-based on single node)"
