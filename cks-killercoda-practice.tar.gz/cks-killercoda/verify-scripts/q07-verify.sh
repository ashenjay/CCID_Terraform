#!/bin/bash
echo "=== Q7 Verification ==="
PASS=true

echo -n "[1] deny-policy exists in prod namespace: "
kubectl -n prod get networkpolicy deny-policy &>/dev/null && echo "PASS ✅" || { echo "FAIL ❌"; PASS=false; }

echo -n "[2] deny-policy blocks all ingress: "
INGRESS=$(kubectl -n prod get networkpolicy deny-policy -o jsonpath='{.spec.policyTypes}' 2>/dev/null)
echo "$INGRESS" | grep -q 'Ingress' && echo "PASS ✅" || { echo "FAIL ❌"; PASS=false; }

echo -n "[3] deny-policy has empty podSelector (all pods): "
PS=$(kubectl -n prod get networkpolicy deny-policy -o jsonpath='{.spec.podSelector}' 2>/dev/null)
if [ "$PS" = "{}" ] || [ "$PS" = "" ]; then echo "PASS ✅"; else echo "FAIL ❌"; PASS=false; fi

echo -n "[4] allow-from-prod exists in data namespace: "
kubectl -n data get networkpolicy allow-from-prod &>/dev/null && echo "PASS ✅" || { echo "FAIL ❌"; PASS=false; }

echo -n "[5] allow-from-prod allows from prod namespace (env=prod): "
kubectl -n data get networkpolicy allow-from-prod -o yaml 2>/dev/null | grep -q 'env: prod' && echo "PASS ✅" || { echo "FAIL ❌"; PASS=false; }

echo ""
if $PASS; then echo "✅ Q7 ALL CHECKS PASSED"; else echo "❌ Q7 SOME CHECKS FAILED"; fi
