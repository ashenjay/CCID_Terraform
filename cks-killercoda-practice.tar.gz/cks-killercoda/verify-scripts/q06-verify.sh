#!/bin/bash
echo "=== Q6 Verification ==="
PASS=true

APISERVER="/etc/kubernetes/manifests/kube-apiserver.yaml"
POLICY="/etc/kubernetes/logpolicy/sample-policy.yaml"

echo -n "[1] audit-policy-file flag set: "
grep -q 'audit-policy-file' $APISERVER && echo "PASS ✅" || { echo "FAIL ❌"; PASS=false; }

echo -n "[2] audit-log-path flag set: "
grep -q 'audit-log-path=/var/log/kubernetes/audit-logs.txt' $APISERVER && echo "PASS ✅" || { echo "FAIL ❌"; PASS=false; }

echo -n "[3] audit-log-maxage=10: "
grep -q 'audit-log-maxage=10' $APISERVER && echo "PASS ✅" || { echo "FAIL ❌"; PASS=false; }

echo -n "[4] audit-log-maxbackup=2: "
grep -q 'audit-log-maxbackup=2' $APISERVER && echo "PASS ✅" || { echo "FAIL ❌"; PASS=false; }

echo -n "[5] Policy has RequestResponse for persistentvolumes: "
grep -q 'RequestResponse' $POLICY && grep -q 'persistentvolumes' $POLICY && echo "PASS ✅" || { echo "FAIL ❌"; PASS=false; }

echo -n "[6] Policy has Request level for configmaps in front-apps: "
grep -q 'Request' $POLICY && grep -q 'configmaps' $POLICY && grep -q 'front-apps' $POLICY && echo "PASS ✅" || { echo "FAIL ❌"; PASS=false; }

echo -n "[7] Policy has Metadata level for secrets+configmaps: "
grep -q 'secrets' $POLICY && echo "PASS ✅" || { echo "FAIL ❌"; PASS=false; }

echo -n "[8] Policy has catch-all Metadata rule: "
# Check last rule is Metadata
grep -c 'level: Metadata' $POLICY | grep -q '[2-9]' && echo "PASS ✅" || { echo "FAIL ❌"; PASS=false; }

echo -n "[9] Audit log file exists: "
if [ -f /var/log/kubernetes/audit-logs.txt ]; then echo "PASS ✅"; else echo "WARN ⚠️ (apiserver may need time to restart)"; fi

echo ""
if $PASS; then echo "✅ Q6 ALL CHECKS PASSED"; else echo "❌ Q6 SOME CHECKS FAILED"; fi
