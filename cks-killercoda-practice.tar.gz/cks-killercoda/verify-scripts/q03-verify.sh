#!/bin/bash
echo "=== Q3 Verification ==="
PASS=true

echo -n "[1] Dockerfile USER is nobody (not root): "
if grep -q 'USER nobody' /cks/docker/Dockerfile && ! grep -q 'USER root' /cks/docker/Dockerfile; then
  echo "PASS ✅"
else
  echo "FAIL ❌"; PASS=false
fi

echo -n "[2] deployment.yaml privileged is false: "
if grep -q 'privileged: false' /cks/docker/deployment.yaml; then
  echo "PASS ✅"
else
  echo "FAIL ❌"; PASS=false
fi

echo -n "[3] deployment.yaml readOnlyRootFilesystem is true: "
if grep -q 'readOnlyRootFilesystem: true' /cks/docker/deployment.yaml; then
  echo "PASS ✅"
else
  echo "FAIL ❌"; PASS=false
fi

echo -n "[4] deployment.yaml runAsUser is 65535: "
if grep -q 'runAsUser: 65535' /cks/docker/deployment.yaml; then
  echo "PASS ✅"
else
  echo "FAIL ❌"; PASS=false
fi

echo ""
if $PASS; then echo "✅ Q3 ALL CHECKS PASSED"; else echo "❌ Q3 SOME CHECKS FAILED"; fi
