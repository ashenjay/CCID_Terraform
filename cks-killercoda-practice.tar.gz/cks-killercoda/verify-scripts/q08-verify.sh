#!/bin/bash
echo "=== Q8 Verification ==="
PASS=true

echo -n "[1] Ingress 'web' exists in prod02: "
kubectl -n prod02 get ingress web &>/dev/null && echo "PASS ✅" || { echo "FAIL ❌"; PASS=false; }

echo -n "[2] Ingress has host web.k8sng.local: "
kubectl -n prod02 get ingress web -o yaml 2>/dev/null | grep -q 'web.k8sng.local' && echo "PASS ✅" || { echo "FAIL ❌"; PASS=false; }

echo -n "[3] Ingress has TLS with secretName web-cert: "
kubectl -n prod02 get ingress web -o yaml 2>/dev/null | grep -q 'web-cert' && echo "PASS ✅" || { echo "FAIL ❌"; PASS=false; }

echo -n "[4] Ingress has ssl-redirect annotation: "
kubectl -n prod02 get ingress web -o yaml 2>/dev/null | grep -q 'ssl-redirect' && echo "PASS ✅" || { echo "FAIL ❌"; PASS=false; }

echo -n "[5] Ingress backend points to service 'web': "
kubectl -n prod02 get ingress web -o yaml 2>/dev/null | grep -q 'name: web' && echo "PASS ✅" || { echo "FAIL ❌"; PASS=false; }

echo ""
if $PASS; then echo "✅ Q8 ALL CHECKS PASSED"; else echo "❌ Q8 SOME CHECKS FAILED"; fi
