#!/bin/bash
echo "=== Q16 Verification ==="
PASS=true
APISERVER="/etc/kubernetes/manifests/kube-apiserver.yaml"
KC="--kubeconfig=/etc/kubernetes/admin.conf"

echo -n "[1] anonymous-auth=false: "
if grep -q '\-\-anonymous-auth=false' $APISERVER; then echo "PASS ✅"; else echo "FAIL ❌"; PASS=false; fi

echo -n "[2] authorization-mode includes Node,RBAC: "
if grep -q 'authorization-mode=Node,RBAC' $APISERVER; then echo "PASS ✅"
elif grep -q 'authorization-mode' $APISERVER && grep 'authorization-mode' $APISERVER | grep -q 'Node' && grep 'authorization-mode' $APISERVER | grep -q 'RBAC'; then
  echo "PASS ✅"
else echo "FAIL ❌"; PASS=false; fi

echo -n "[3] admission-plugins=NodeRestriction (not AlwaysAdmit): "
if grep -q 'enable-admission-plugins=NodeRestriction' $APISERVER && ! grep -q 'AlwaysAdmit' $APISERVER; then
  echo "PASS ✅"
elif grep 'enable-admission-plugins' $APISERVER | grep -q 'NodeRestriction'; then
  echo "PASS ✅"
else echo "FAIL ❌"; PASS=false; fi

echo -n "[4] ClusterRoleBinding system:anonymous deleted: "
if ! kubectl $KC get clusterrolebinding system:anonymous &>/dev/null; then
  echo "PASS ✅"
else echo "FAIL ❌ (still exists)"; PASS=false; fi

echo -n "[5] kube-apiserver running: "
if kubectl $KC -n kube-system get pod -l component=kube-apiserver 2>/dev/null | grep -q Running; then
  echo "PASS ✅"
elif kubectl -n kube-system get pod -l component=kube-apiserver 2>/dev/null | grep -q Running; then
  echo "PASS ✅"
else echo "WARN ⚠️ (may need a few minutes)"; fi

echo ""
if $PASS; then echo "✅ Q16 ALL CHECKS PASSED"; else echo "❌ Q16 SOME CHECKS FAILED"; fi
