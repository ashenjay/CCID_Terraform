#!/bin/bash
echo "=== Q5 Verification ==="
PASS=true

for c in sec-ctx-demo-1 sec-ctx-demo-2; do
  echo "--- Container: $c ---"

  echo -n "  runAsUser=30000: "
  VAL=$(kubectl -n sec-ns get deployment secdep -o jsonpath="{.spec.template.spec.containers[?(@.name=='$c')].securityContext.runAsUser}" 2>/dev/null)
  if [ "$VAL" = "30000" ]; then echo "PASS ✅"; else echo "FAIL ❌ (got $VAL)"; PASS=false; fi

  echo -n "  readOnlyRootFilesystem=true: "
  VAL=$(kubectl -n sec-ns get deployment secdep -o jsonpath="{.spec.template.spec.containers[?(@.name=='$c')].securityContext.readOnlyRootFilesystem}" 2>/dev/null)
  if [ "$VAL" = "true" ]; then echo "PASS ✅"; else echo "FAIL ❌ (got $VAL)"; PASS=false; fi

  echo -n "  allowPrivilegeEscalation=false: "
  VAL=$(kubectl -n sec-ns get deployment secdep -o jsonpath="{.spec.template.spec.containers[?(@.name=='$c')].securityContext.allowPrivilegeEscalation}" 2>/dev/null)
  if [ "$VAL" = "false" ]; then echo "PASS ✅"; else echo "FAIL ❌ (got $VAL)"; PASS=false; fi
done

echo ""
if $PASS; then echo "✅ Q5 ALL CHECKS PASSED"; else echo "❌ Q5 SOME CHECKS FAILED"; fi
