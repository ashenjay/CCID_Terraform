#!/bin/bash
echo "=== Q1 Verification ==="
PASS=true

# Check kubelet config
echo -n "[1] anonymous-auth is false: "
if grep -A1 'anonymous:' /var/lib/kubelet/config.yaml | grep -q 'enabled: false'; then
  echo "PASS ✅"
else
  echo "FAIL ❌"; PASS=false
fi

echo -n "[2] authorization mode is Webhook: "
if grep -q 'mode: Webhook' /var/lib/kubelet/config.yaml; then
  echo "PASS ✅"
else
  echo "FAIL ❌"; PASS=false
fi

echo -n "[3] webhook auth enabled: "
if grep -A2 'webhook:' /var/lib/kubelet/config.yaml | grep -q 'enabled: true'; then
  echo "PASS ✅"
else
  echo "FAIL ❌"; PASS=false
fi

# Check etcd config
echo -n "[4] etcd client-cert-auth is true: "
if grep -q '\-\-client-cert-auth=true' /etc/kubernetes/manifests/etcd.yaml; then
  echo "PASS ✅"
else
  echo "FAIL ❌"; PASS=false
fi

# Check API server is running
echo -n "[5] kube-apiserver running: "
if kubectl get pod -n kube-system -l component=kube-apiserver 2>/dev/null | grep -q Running; then
  echo "PASS ✅"
else
  echo "WARN ⚠️  (may need a few minutes to recover)"; PASS=false
fi

echo ""
if $PASS; then echo "✅ Q1 ALL CHECKS PASSED"; else echo "❌ Q1 SOME CHECKS FAILED"; fi
