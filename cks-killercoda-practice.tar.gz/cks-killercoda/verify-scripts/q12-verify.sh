#!/bin/bash
echo "=== Q12 Verification ==="
PASS=true

echo -n "[1] Deployment exists and has pods: "
READY=$(kubectl -n confidential get deployment nginx-unprivileged -o jsonpath='{.status.readyReplicas}' 2>/dev/null)
if [ "$READY" = "1" ]; then echo "PASS ✅"; else echo "FAIL ❌ (readyReplicas=$READY)"; PASS=false; fi

echo -n "[2] allowPrivilegeEscalation=false: "
kubectl -n confidential get deployment nginx-unprivileged -o yaml 2>/dev/null | grep -q 'allowPrivilegeEscalation: false' && echo "PASS ✅" || { echo "FAIL ❌"; PASS=false; }

echo -n "[3] capabilities drop ALL: "
kubectl -n confidential get deployment nginx-unprivileged -o yaml 2>/dev/null | grep -q 'ALL' && echo "PASS ✅" || { echo "FAIL ❌"; PASS=false; }

echo -n "[4] runAsNonRoot=true: "
kubectl -n confidential get deployment nginx-unprivileged -o yaml 2>/dev/null | grep -q 'runAsNonRoot: true' && echo "PASS ✅" || { echo "FAIL ❌"; PASS=false; }

echo -n "[5] seccompProfile RuntimeDefault: "
kubectl -n confidential get deployment nginx-unprivileged -o yaml 2>/dev/null | grep -q 'RuntimeDefault' && echo "PASS ✅" || { echo "FAIL ❌"; PASS=false; }

echo ""
if $PASS; then echo "✅ Q12 ALL CHECKS PASSED"; else echo "❌ Q12 SOME CHECKS FAILED"; fi
