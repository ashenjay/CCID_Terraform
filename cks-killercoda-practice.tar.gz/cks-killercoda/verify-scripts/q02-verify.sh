#!/bin/bash
echo "=== Q2 Verification ==="
PASS=true

echo -n "[1] TLS Secret 'clever-cactus' exists in namespace: "
if kubectl -n clever-cactus get secret clever-cactus -o jsonpath='{.type}' 2>/dev/null | grep -q 'tls'; then
  echo "PASS ✅"
else
  echo "FAIL ❌"; PASS=false
fi

echo -n "[2] Secret has tls.crt key: "
if kubectl -n clever-cactus get secret clever-cactus -o jsonpath='{.data.tls\.crt}' 2>/dev/null | grep -q '.'; then
  echo "PASS ✅"
else
  echo "FAIL ❌"; PASS=false
fi

echo -n "[3] Secret has tls.key key: "
if kubectl -n clever-cactus get secret clever-cactus -o jsonpath='{.data.tls\.key}' 2>/dev/null | grep -q '.'; then
  echo "PASS ✅"
else
  echo "FAIL ❌"; PASS=false
fi

echo ""
if $PASS; then echo "✅ Q2 ALL CHECKS PASSED"; else echo "❌ Q2 SOME CHECKS FAILED"; fi
