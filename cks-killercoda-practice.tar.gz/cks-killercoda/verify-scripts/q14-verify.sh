#!/bin/bash
echo "=== Q14 Verification ==="
PASS=true

echo -n "[1] mtls namespace has istio-injection=enabled label: "
LABEL=$(kubectl get namespace mtls -o jsonpath='{.metadata.labels.istio-injection}' 2>/dev/null)
if [ "$LABEL" = "enabled" ]; then echo "PASS ✅"; else echo "FAIL ❌ (got '$LABEL')"; PASS=false; fi

echo -n "[2] Deployments were restarted (rollout): "
# Check if restartedAt annotation exists (set by rollout restart)
if kubectl -n mtls get deployment frontend -o yaml 2>/dev/null | grep -q 'restartedAt'; then
  echo "PASS ✅"
else
  echo "WARN ⚠️ (no restartedAt annotation — run: kubectl -n mtls rollout restart deployment)"
fi

echo -n "[3] PeerAuthentication exists in mtls namespace: "
if kubectl -n mtls get peerauthentication default &>/dev/null; then
  echo "PASS ✅"

  echo -n "[4] PeerAuthentication mode is STRICT: "
  MODE=$(kubectl -n mtls get peerauthentication default -o jsonpath='{.spec.mtls.mode}' 2>/dev/null)
  if [ "$MODE" = "STRICT" ]; then echo "PASS ✅"; else echo "FAIL ❌ (got '$MODE')"; PASS=false; fi
else
  echo "SKIP ⚠️ (Istio CRDs not installed — verify YAML is correct manually)"
  echo ""
  echo "Expected YAML:"
  echo "  apiVersion: security.istio.io/v1"
  echo "  kind: PeerAuthentication"
  echo "  metadata:"
  echo "    name: default"
  echo "    namespace: mtls"
  echo "  spec:"
  echo "    mtls:"
  echo "      mode: STRICT"
fi

echo ""
if $PASS; then echo "✅ Q14 ALL CHECKS PASSED"; else echo "❌ Q14 SOME CHECKS FAILED (or Istio not installed)"; fi
