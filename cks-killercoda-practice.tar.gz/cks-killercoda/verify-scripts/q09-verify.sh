#!/bin/bash
echo "=== Q9 Verification ==="
PASS=true

echo -n "[1] SA automountServiceAccountToken=false: "
VAL=$(kubectl -n monitoring get sa stats-monitor-sa -o jsonpath='{.automountServiceAccountToken}' 2>/dev/null)
if [ "$VAL" = "false" ]; then echo "PASS ✅"; else echo "FAIL ❌ (got $VAL)"; PASS=false; fi

echo -n "[2] Deployment has projected volume 'token': "
kubectl -n monitoring get deployment stats-monitor -o yaml 2>/dev/null | grep -q 'name: token' && echo "PASS ✅" || { echo "FAIL ❌"; PASS=false; }

echo -n "[3] Deployment has serviceAccountToken in projected sources: "
kubectl -n monitoring get deployment stats-monitor -o yaml 2>/dev/null | grep -q 'serviceAccountToken' && echo "PASS ✅" || { echo "FAIL ❌"; PASS=false; }

echo -n "[4] Volume mounted at correct path: "
kubectl -n monitoring get deployment stats-monitor -o yaml 2>/dev/null | grep -q '/var/run/secrets/kubernetes.io/serviceaccount/token' && echo "PASS ✅" || { echo "FAIL ❌"; PASS=false; }

echo -n "[5] Mount is readOnly: "
kubectl -n monitoring get deployment stats-monitor -o yaml 2>/dev/null | grep -A1 'name: token' | grep -q 'readOnly: true' && echo "PASS ✅" || { echo "WARN ⚠️ (check manually)"; }

echo ""
if $PASS; then echo "✅ Q9 ALL CHECKS PASSED"; else echo "❌ Q9 SOME CHECKS FAILED"; fi
