#!/bin/bash
echo "=== Q15 Setup: ImagePolicyWebhook ==="

mkdir -p /etc/kubernetes/epconfig

# Generate a dummy server cert for the webhook config
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout /etc/kubernetes/epconfig/server.key \
  -out /etc/kubernetes/epconfig/server.crt \
  -subj "/CN=image-bouncer-webhook" 2>/dev/null

# Create admission config that references image-policy-config.yaml
cat > /etc/kubernetes/epconfig/admission-config.yaml <<'EOF'
apiVersion: apiserver.config.k8s.io/v1
kind: AdmissionConfiguration
plugins:
- name: ImagePolicyWebhook
  configuration:
    imagePolicy:
      kubeConfigFile: /etc/kubernetes/epconfig/kube-config.yaml
      allowTTL: 50
      denyTTL: 50
      retryBackoff: 500
      defaultAllow: true
EOF

# Create image-policy-config.yaml (intentionally wrong: defaultAllow=true)
cat > /etc/kubernetes/epconfig/image-policy-config.yaml <<'EOF'
imagePolicy:
  kubeConfigFile: /etc/kubernetes/epconfig/kube-config.yaml
  allowTTL: 50
  denyTTL: 50
  retryBackoff: 500
  defaultAllow: true
EOF

# Create kube-config.yaml (missing server address)
cat > /etc/kubernetes/epconfig/kube-config.yaml <<'EOF'
apiVersion: v1
kind: Config
clusters:
- cluster:
    certificate-authority: /etc/kubernetes/epconfig/server.crt
    server:
  name: bouncer_webhook
contexts:
- context:
    cluster: bouncer_webhook
    user: api-server
  name: bouncer_validator
current-context: bouncer_validator
preferences: {}
users:
- name: api-server
  user:
    client-certificate: /etc/kubernetes/epconfig/server.crt
    client-key: /etc/kubernetes/epconfig/server.key
EOF

# Create test deployment yaml
cat > ~/web1.yaml <<'EOF'
apiVersion: v1
kind: Pod
metadata:
  name: web1
spec:
  containers:
  - name: web1
    image: nginx:latest
EOF

# Remove ImagePolicyWebhook from apiserver if present (simulate broken state)
APISERVER="/etc/kubernetes/manifests/kube-apiserver.yaml"
cp $APISERVER ${APISERVER}.q15bak
sed -i 's/,ImagePolicyWebhook//g' $APISERVER
sed -i '/admission-control-config-file/d' $APISERVER

echo ""
echo "=== Q15 Setup Complete ==="
echo "Files created in /etc/kubernetes/epconfig/"
echo "Read the question: cat questions/q15.txt"
echo ""
echo "You need to:"
echo "  1. Fix defaultAllow to false in image-policy-config.yaml"
echo "  2. Add webhook server URL in kube-config.yaml"
echo "  3. Add ImagePolicyWebhook admission plugin to kube-apiserver.yaml"
echo "  4. Add admission-control-config-file flag to kube-apiserver.yaml"
echo "  5. Add volumeMount + hostPath for /etc/kubernetes/epconfig"
