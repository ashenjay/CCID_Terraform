#!/bin/bash
echo "=== Q11 Setup: BOM / SPDX ==="

kubectl create namespace alpine --dry-run=client -o yaml | kubectl apply -f -

cat > ~/alipine-deployment.yaml <<'EOF'
apiVersion: apps/v1
kind: Deployment
metadata:
  name: alpine
  namespace: alpine
spec:
  replicas: 1
  selector:
    matchLabels:
      app: alpine
  template:
    metadata:
      labels:
        app: alpine
    spec:
      containers:
      - name: alpine-a
        image: alpine:3.18
        imagePullPolicy: IfNotPresent
        args:
        - /bin/sh
        - -c
        - while true; do sleep 360000; done
      - name: alpine-b
        image: alpine:3.19.1
        imagePullPolicy: IfNotPresent
        args:
        - /bin/sh
        - -c
        - while true; do sleep 360000; done
      - name: alpine-c
        image: alpine:3.20
        imagePullPolicy: IfNotPresent
        args:
        - /bin/sh
        - -c
        - while true; do sleep 360000; done
EOF

kubectl apply -f ~/alipine-deployment.yaml

echo "=== Q11 Setup Complete ==="
echo "Read the question: cat questions/q11.txt"
echo "NOTE: In the real exam, alpine-b (3.19.1) has libcrypto3 3.1.4-r5"
