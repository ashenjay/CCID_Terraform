#!/bin/bash
echo "=== Q10 Setup: Upgrade Cluster Node ==="
echo ""
echo "Current node versions:"
kubectl get nodes
echo ""
echo "NOTE: On Killercoda single-node, this is a knowledge-based exercise."
echo "Practice the upgrade commands conceptually."
echo "In the real exam, you SSH to node02 and run:"
echo "  apt install kubelet=<version>-1.1 kubeadm=<version>-1.1 kubectl=<version>-1.1"
echo "  systemctl daemon-reload && systemctl restart kubelet"
echo ""
echo "Read the question: cat questions/q10.txt"
