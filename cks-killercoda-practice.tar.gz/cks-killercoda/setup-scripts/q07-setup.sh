#!/bin/bash
echo "=== Q7 Setup: Network Policy ==="

kubectl create namespace prod --dry-run=client -o yaml | kubectl apply -f -
kubectl create namespace data --dry-run=client -o yaml | kubectl apply -f -
kubectl label namespace prod env=prod --overwrite
kubectl label namespace data env=data --overwrite

# Create test pods
kubectl -n prod run web --image=nginx:alpine --labels="app=web" --dry-run=client -o yaml | kubectl apply -f -
kubectl -n data run db --image=nginx:alpine --labels="app=db" --dry-run=client -o yaml | kubectl apply -f -

echo "=== Q7 Setup Complete ==="
echo "Read the question: cat questions/q07.txt"
