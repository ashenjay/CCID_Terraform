#!/bin/bash
echo "=== Q2 Setup: TLS Secret ==="

kubectl create namespace clever-cactus --dry-run=client -o yaml | kubectl apply -f -

# Ensure certs exist (created by master-setup)
mkdir -p ~/ca-cert
if [ ! -f ~/ca-cert/web.k8s.local.crt ]; then
  openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
    -keyout ~/ca-cert/web.k8s.local.key \
    -out ~/ca-cert/web.k8s.local.crt \
    -subj "/CN=web.k8s.local/O=CKS-Practice" 2>/dev/null
fi

# Also place certs at exam-like path
mkdir -p /home/candidate/ca-cert
cp ~/ca-cert/web.k8s.local.crt /home/candidate/ca-cert/ 2>/dev/null || true
cp ~/ca-cert/web.k8s.local.key /home/candidate/ca-cert/ 2>/dev/null || true

# Create Deployment that depends on a TLS secret
cat <<'EOF' | kubectl apply -f -
apiVersion: apps/v1
kind: Deployment
metadata:
  name: clever-cactus
  namespace: clever-cactus
spec:
  replicas: 1
  selector:
    matchLabels:
      app: clever-cactus
  template:
    metadata:
      labels:
        app: clever-cactus
    spec:
      containers:
      - name: nginx
        image: nginx:alpine
        ports:
        - containerPort: 443
        volumeMounts:
        - name: tls-certs
          mountPath: /etc/nginx/ssl
          readOnly: true
      volumes:
      - name: tls-certs
        secret:
          secretName: clever-cactus
          optional: true
EOF

echo ""
echo "=== Q2 Setup Complete ==="
echo "Read the question: cat questions/q02.txt"
