#!/bin/bash
echo "=== Q4 Setup: Falco /dev/mem Detection ==="

# Create multiple deployments - one is the offender
cat <<'EOF' | kubectl apply -f -
apiVersion: apps/v1
kind: Deployment
metadata:
  name: web
  namespace: default
spec:
  replicas: 1
  selector:
    matchLabels:
      app: web
  template:
    metadata:
      labels:
        app: web
    spec:
      containers:
      - name: web
        image: busybox:1.36
        command: ["sh", "-c", "while true; do echo hello; sleep 3600; done"]
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: cpu
  namespace: default
spec:
  replicas: 1
  selector:
    matchLabels:
      app: cpu
  template:
    metadata:
      labels:
        app: cpu
    spec:
      containers:
      - name: cpu
        image: busybox:1.36
        command: ["sh", "-c", "while true; do cat /dev/urandom > /dev/null & sleep 5; kill %1; sleep 10; done"]
        securityContext:
          privileged: true
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: api
  namespace: default
spec:
  replicas: 1
  selector:
    matchLabels:
      app: api
  template:
    metadata:
      labels:
        app: api
    spec:
      containers:
      - name: api
        image: busybox:1.36
        command: ["sh", "-c", "while true; do echo api; sleep 3600; done"]
EOF

mkdir -p /etc/falco
echo "" > /etc/falco/falco_rules.local.yaml

echo ""
echo "=== Q4 Setup Complete ==="
echo "Deployments created: web, cpu, api"
echo "NOTE: On Killercoda, the 'cpu' deployment simulates the offender."
echo "      In the real exam, you use Falco to detect which pod reads /dev/mem."
echo "Read the question: cat questions/q04.txt"
