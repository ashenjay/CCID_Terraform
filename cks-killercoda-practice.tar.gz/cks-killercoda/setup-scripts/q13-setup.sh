#!/bin/bash
echo "=== Q13 Setup: Docker Daemon Hardening ==="

# Create developer user and docker group if they don't exist
groupadd docker 2>/dev/null || true
useradd -m developer 2>/dev/null || true
usermod -aG docker developer 2>/dev/null || true

# Create simulated docker.socket and docker.service files
mkdir -p /usr/lib/systemd/system

if [ ! -f /usr/lib/systemd/system/docker.socket ]; then
cat > /usr/lib/systemd/system/docker.socket <<'EOF'
[Unit]
Description=Docker Socket for the API

[Socket]
ListenStream=/run/docker.sock
SocketMode=0660
SocketUser=root
SocketGroup=docker

[Install]
WantedBy=sockets.target
EOF
fi

if [ ! -f /usr/lib/systemd/system/docker.service ]; then
cat > /usr/lib/systemd/system/docker.service <<'EOF'
[Unit]
Description=Docker Application Container Engine

[Service]
ExecStart=/usr/bin/dockerd -H fd:// -H tcp://0.0.0.0:2375 --containerd=/run/containerd/containerd.sock

[Install]
WantedBy=multi-user.target
EOF
fi

echo "=== Q13 Setup Complete ==="
echo "NOTE: Docker may not be installed on Killercoda."
echo "Practice editing the config files for the exam."
echo "Read the question: cat questions/q13.txt"
