#!/bin/bash
echo "=== Q12 Setup: Restricted Pod Security Standard ==="

kubectl create namespace confidential --dry-run=client -o yaml | kubectl apply -f -

# Apply restricted PSS enforcement
kubectl label namespace confidential pod-security.kubernetes.io/enforce=restricted --overwrite
kubectl label namespace confidential pod-security.kubernetes.io/warn=restricted --overwrite

cat > ~/nginx-unprivileged.yaml <<'EOF'
apiVersion: apps/v1
kind: Deployment
metadata:
  name: nginx-unprivileged
  namespace: confidential
spec:
  replicas: 1
  selector:
    matchLabels:
      app: nginx-unprivileged
  template:
    metadata:
      labels:
        app: nginx-unprivileged
    spec:
      containers:
      - name: nginx
        image: nginxinc/nginx-unprivileged:latest
        ports:
        - containerPort: 8080
EOF

# This will fail due to PSS restrictions
kubectl apply -f ~/nginx-unprivileged.yaml 2>/dev/null || true

echo ""
echo "=== Q12 Setup Complete ==="
echo "The deployment will be non-compliant. Fix it!"
echo "Read the question: cat questions/q12.txt"
