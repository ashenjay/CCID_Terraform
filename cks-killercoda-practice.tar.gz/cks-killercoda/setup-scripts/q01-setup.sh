#!/bin/bash
echo "=== Q1 Setup: Breaking kubelet and etcd configs ==="

# Break kubelet config: set anonymous-auth to true, authorization mode to AlwaysAllow
KUBELET_CONFIG="/var/lib/kubelet/config.yaml"
cp $KUBELET_CONFIG ${KUBELET_CONFIG}.bak

# Set anonymous auth to true
sed -i '/anonymous:/,/enabled:/{s/enabled: false/enabled: true/}' $KUBELET_CONFIG
# Set webhook enabled to false
sed -i '/webhook:/,/enabled:/{s/enabled: true/enabled: false/}' $KUBELET_CONFIG
# Set authorization mode to AlwaysAllow
sed -i 's/mode: Webhook/mode: AlwaysAllow/' $KUBELET_CONFIG

# Break etcd config: set client-cert-auth to false
ETCD_MANIFEST="/etc/kubernetes/manifests/etcd.yaml"
cp $ETCD_MANIFEST ${ETCD_MANIFEST}.bak
sed -i 's/--client-cert-auth=true/--client-cert-auth=false/' $ETCD_MANIFEST

systemctl daemon-reload
systemctl restart kubelet

echo ""
echo "=== Q1 Setup Complete ==="
echo "Read the question: cat questions/q01.txt"
echo "Verify after solving: bash verify-scripts/q01-verify.sh"
