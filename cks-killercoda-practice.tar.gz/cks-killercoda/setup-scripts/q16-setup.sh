#!/bin/bash
echo "=== Q16 Setup: API Server Authentication ==="

APISERVER="/etc/kubernetes/manifests/kube-apiserver.yaml"
cp $APISERVER ${APISERVER}.q16bak

# Break the API server: enable anonymous auth, set AlwaysAdmit
sed -i 's/--anonymous-auth=false/--anonymous-auth=true/' $APISERVER
# If anonymous-auth doesn't exist, it defaults to true which is what we want
sed -i 's/--enable-admission-plugins=NodeRestriction/--enable-admission-plugins=AlwaysAdmit/' $APISERVER

# Create the system:anonymous ClusterRoleBinding
cat <<'EOF' | kubectl apply -f - 2>/dev/null || true
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: system:anonymous
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: cluster-admin
subjects:
- apiGroup: rbac.authorization.k8s.io
  kind: User
  name: system:anonymous
EOF

systemctl daemon-reload
systemctl restart kubelet

echo ""
echo "=== Q16 Setup Complete ==="
echo "The API server is now insecure. Fix it!"
echo "Read the question: cat questions/q16.txt"
echo ""
echo "IMPORTANT: After fixing, use:"
echo "  kubectl --kubeconfig=/etc/kubernetes/admin.conf get pod -A"
