#!/bin/bash
echo "=== Q9 Setup: Disable SA Auto-Mount ==="

kubectl create namespace monitoring --dry-run=client -o yaml | kubectl apply -f -
kubectl -n monitoring create serviceaccount stats-monitor-sa --dry-run=client -o yaml | kubectl apply -f -

mkdir -p ~/stats-monitor

# Create configmap for httpd.conf
kubectl -n monitoring create configmap httpcf --from-literal=httpd.conf="ServerRoot /usr/local/apache2" --dry-run=client -o yaml | kubectl apply -f -

cat > ~/stats-monitor/deployment.yaml <<'EOF'
apiVersion: apps/v1
kind: Deployment
metadata:
  name: stats-monitor
  namespace: monitoring
  labels:
    app: stats-monitor
spec:
  replicas: 1
  selector:
    matchLabels:
      app: stats-monitor
  template:
    metadata:
      labels:
        app: stats-monitor
    spec:
      serviceAccountName: stats-monitor-sa
      containers:
      - name: nginx
        image: nginx:alpine
        imagePullPolicy: IfNotPresent
        volumeMounts:
        - mountPath: /usr/local/apache2/conf/httpd.conf
          name: httpcf
          subPath: httpd.conf
      volumes:
      - configMap:
          items:
          - key: httpd.conf
            path: httpd.conf
          name: httpcf
        name: httpcf
EOF

kubectl apply -f ~/stats-monitor/deployment.yaml

echo "=== Q9 Setup Complete ==="
echo "Read the question: cat questions/q09.txt"
