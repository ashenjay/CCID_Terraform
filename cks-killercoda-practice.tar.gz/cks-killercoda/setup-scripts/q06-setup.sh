#!/bin/bash
echo "=== Q6 Setup: Audit Policy ==="

mkdir -p /etc/kubernetes/logpolicy
mkdir -p /var/log/kubernetes
kubectl create namespace front-apps --dry-run=client -o yaml | kubectl apply -f -

# Create a basic audit policy (only specifies what NOT to log)
cat > /etc/kubernetes/logpolicy/sample-policy.yaml <<'EOF'
apiVersion: audit.k8s.io/v1
kind: Policy
rules:
  # Don't log requests to the following
  - level: None
    resources:
    - group: ""
      resources: ["events"]
  # ---- ADD YOUR RULES BELOW THIS LINE ----
EOF

# Remove any existing audit flags from apiserver (simulate broken state)
APISERVER="/etc/kubernetes/manifests/kube-apiserver.yaml"
cp $APISERVER ${APISERVER}.q6bak
sed -i '/--audit-policy-file/d' $APISERVER
sed -i '/--audit-log-path/d' $APISERVER
sed -i '/--audit-log-maxage/d' $APISERVER
sed -i '/--audit-log-maxbackup/d' $APISERVER

echo "=== Q6 Setup Complete ==="
echo "Read the question: cat questions/q06.txt"
echo ""
echo "IMPORTANT: You need to add audit flags to kube-apiserver.yaml"
echo "AND add the corresponding volumeMounts and hostPath volumes."
