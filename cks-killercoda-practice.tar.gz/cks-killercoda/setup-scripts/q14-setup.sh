#!/bin/bash
echo "=== Q14 Setup: Istio mTLS ==="

kubectl create namespace mtls --dry-run=client -o yaml | kubectl apply -f -

# Create test deployments in mtls namespace
for app in frontend backend; do
cat <<EOF | kubectl apply -f -
apiVersion: apps/v1
kind: Deployment
metadata:
  name: $app
  namespace: mtls
spec:
  replicas: 1
  selector:
    matchLabels:
      app: $app
  template:
    metadata:
      labels:
        app: $app
    spec:
      containers:
      - name: $app
        image: nginx:alpine
        ports:
        - containerPort: 80
EOF
done

# Check if Istio CRDs exist
if kubectl api-resources 2>/dev/null | grep -q peerauthentication; then
  echo "Istio CRDs detected — full practice available."
else
  echo ""
  echo "WARNING: Istio is NOT installed on this cluster."
  echo "To install Istio on Killercoda (optional):"
  echo "  curl -L https://istio.io/downloadIstio | ISTIO_VERSION=1.24.0 sh -"
  echo "  export PATH=\$PWD/istio-1.24.0/bin:\$PATH"
  echo "  istioctl install --set profile=minimal -y"
  echo ""
  echo "Without Istio you can still practice:"
  echo "  - The namespace labeling command"
  echo "  - Writing the PeerAuthentication YAML"
  echo "  - The rollout restart command"
fi

echo ""
echo "=== Q14 Setup Complete ==="
echo "Read the question: cat questions/q14.txt"
