#!/bin/bash
echo "=== Q3 Setup: Dockerfile Security ==="

mkdir -p /cks/docker

cat > /cks/docker/Dockerfile <<'EOF'
FROM ubuntu:22.04
RUN apt-get update && apt-get install -y nginx
COPY nginx.conf /etc/nginx/nginx.conf
EXPOSE 80
USER root
CMD ["nginx", "-g", "daemon off;"]
EOF

cat > /cks/docker/deployment.yaml <<'EOF'
apiVersion: apps/v1
kind: Deployment
metadata:
  name: web-app
  namespace: default
spec:
  replicas: 1
  selector:
    matchLabels:
      app: web-app
  template:
    metadata:
      labels:
        app: web-app
    spec:
      containers:
      - name: web-app
        image: web-app:latest
        securityContext:
          runAsUser: 0
          readOnlyRootFilesystem: false
          privileged: true
          capabilities:
            drop: ["all"]
            add: ["NET_BIND_SERVICE"]
        ports:
        - containerPort: 80
EOF

echo "=== Q3 Setup Complete ==="
echo "Files created:"
echo "  /cks/docker/Dockerfile"
echo "  /cks/docker/deployment.yaml"
echo "Read the question: cat questions/q03.txt"
