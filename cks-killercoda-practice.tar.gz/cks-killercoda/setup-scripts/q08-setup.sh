#!/bin/bash
echo "=== Q8 Setup: Ingress with TLS ==="

kubectl create namespace prod02 --dry-run=client -o yaml | kubectl apply -f -

# Create TLS secret
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout /tmp/web-tls.key -out /tmp/web-tls.crt \
  -subj "/CN=web.k8sng.local" 2>/dev/null

kubectl -n prod02 create secret tls web-cert \
  --cert=/tmp/web-tls.crt --key=/tmp/web-tls.key \
  --dry-run=client -o yaml | kubectl apply -f -

# Create the web deployment and service
cat <<'EOF' | kubectl apply -f -
apiVersion: apps/v1
kind: Deployment
metadata:
  name: web
  namespace: prod02
spec:
  replicas: 1
  selector:
    matchLabels:
      app: web
  template:
    metadata:
      labels:
        app: web
    spec:
      containers:
      - name: nginx
        image: nginx:alpine
        ports:
        - containerPort: 80
---
apiVersion: v1
kind: Service
metadata:
  name: web
  namespace: prod02
spec:
  selector:
    app: web
  ports:
  - port: 80
    targetPort: 80
EOF

echo "=== Q8 Setup Complete ==="
echo "Check the service port: kubectl -n prod02 get svc web"
echo "Read the question: cat questions/q08.txt"
