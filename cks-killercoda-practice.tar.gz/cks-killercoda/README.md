# CKS Exam Practice Environment for Killercoda

## How to Use

1. Open **Killercoda** → choose **"Kubernetes 1.33"** or **"Ubuntu"** playground
2. Upload or paste the `master-setup.sh` script and run it:
   ```bash
   bash master-setup.sh
   ```
3. This installs all prerequisites (Falco, Istio, bom tool, etc.)
4. For each question, run the corresponding setup script:
   ```bash
   bash setup-scripts/q01-setup.sh
   ```
5. Read the question from `questions/q01.txt`
6. Solve it, then verify with:
   ```bash
   bash verify-scripts/q01-verify.sh
   ```

## Questions Summary

| # | Topic | SSH Target |
|---|-------|------------|
| 1 | CIS Benchmark — kubelet & etcd fixes | master node |
| 2 | TLS Secret for Deployment | master node |
| 3 | Dockerfile & Deployment security fixes | master node |
| 4 | Falco — find Pod accessing /dev/mem | master node |
| 5 | Security Context (runAsUser, readOnly, noEscalation) | master node |
| 6 | Audit Policy & Log Backend | master node |
| 7 | NetworkPolicy (deny all + allow from namespace) | master node |
| 8 | Ingress with TLS termination | master node |
| 9 | Disable SA auto-mount + projected volume | master node |
| 10 | Upgrade worker node (kubeadm) | worker node |
| 11 | BOM tool → SPDX document | master node |
| 12 | Restricted Pod Security Standard | master node |
| 13 | Docker daemon hardening | master node |
| 14 | Istio sidecar injection + mTLS STRICT | master node |
| 15 | ImagePolicyWebhook admission controller | master node |
| 16 | API Server authentication hardening | master node |

> **Tip:** On Killercoda's single-node playground, `ssh node02` won't exist.
> Questions requiring multi-node (Q1, Q4, Q10, Q13) are adapted to run on the control plane node.
