#!/bin/bash
set -e
echo "============================================"
echo "  CKS Practice Environment - Master Setup"
echo "  For Killercoda Kubernetes Playground"
echo "============================================"

# Wait for cluster to be ready
echo "[1/6] Waiting for Kubernetes cluster to be ready..."
kubectl wait --for=condition=Ready node --all --timeout=120s 2>/dev/null || true
kubectl cluster-info

# Create working directories
echo "[2/6] Creating directory structure..."
mkdir -p /cks/docker
mkdir -p /etc/kubernetes/logpolicy
mkdir -p /etc/kubernetes/epconfig
mkdir -p /var/log/kubernetes
mkdir -p ~/stats-monitor
mkdir -p ~/ca-cert

# Install Falco (for Q4)
echo "[3/6] Installing Falco..."
if ! command -v falco &>/dev/null; then
  curl -fsSL https://falco.org/repo/falcosecurity-packages.asc | \
    gpg --dearmor -o /usr/share/keyrings/falco-archive-keyring.gpg 2>/dev/null || true
  echo "deb [signed-by=/usr/share/keyrings/falco-archive-keyring.gpg] https://download.falco.org/packages/deb stable main" \
    > /etc/apt/sources.list.d/falcosecurity.list
  apt-get update -qq && apt-get install -y -qq falco 2>/dev/null || echo "  [WARN] Falco install skipped — install manually if needed for Q4"
fi

# Install bom tool (for Q11)
echo "[4/6] Installing bom tool..."
if ! command -v bom &>/dev/null; then
  BOM_VERSION="v0.6.0"
  curl -fsSL "https://github.com/kubernetes-sigs/bom/releases/download/${BOM_VERSION}/bom-amd64-linux" \
    -o /usr/local/bin/bom 2>/dev/null && chmod +x /usr/local/bin/bom || echo "  [WARN] bom install skipped — install manually if needed for Q11"
fi

# Generate TLS certs for Q2 and Q8
echo "[5/6] Generating TLS certificates..."
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout ~/ca-cert/web.k8s.local.key \
  -out ~/ca-cert/web.k8s.local.crt \
  -subj "/CN=web.k8s.local/O=CKS-Practice" 2>/dev/null

# Create all namespaces
echo "[6/6] Creating namespaces..."
for ns in clever-cactus sec-ns front-apps prod data prod02 monitoring confidential alpine mtls; do
  kubectl create namespace $ns --dry-run=client -o yaml | kubectl apply -f - 2>/dev/null
done

echo ""
echo "============================================"
echo "  Master setup complete!"
echo ""
echo "  Now run individual question setup scripts:"
echo "    bash setup-scripts/q01-setup.sh"
echo "    bash setup-scripts/q02-setup.sh"
echo "    ... etc"
echo "============================================"
