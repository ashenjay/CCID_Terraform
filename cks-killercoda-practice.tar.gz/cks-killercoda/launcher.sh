#!/bin/bash
# CKS Practice Launcher — run any question interactively

QUESTIONS=(
  "Q01: CIS Benchmark — kubelet & etcd"
  "Q02: TLS Secret"
  "Q03: Dockerfile Security"
  "Q04: Falco /dev/mem Detection"
  "Q05: Security Context"
  "Q06: Audit Policy & Log Backend"
  "Q07: Network Policy (Deny + Allow)"
  "Q08: Ingress with TLS"
  "Q09: Disable SA Auto-Mount"
  "Q10: Upgrade Worker Node"
  "Q11: BOM / SPDX Document"
  "Q12: Restricted Pod Security Standard"
  "Q13: Docker Daemon Hardening"
  "Q14: Istio mTLS"
  "Q15: ImagePolicyWebhook"
  "Q16: API Server Authentication"
)

show_menu() {
  echo ""
  echo "╔══════════════════════════════════════════════════╗"
  echo "║     CKS 2026 Practice Environment (v1.33)       ║"
  echo "║     16 Questions — Killercoda Edition            ║"
  echo "╚══════════════════════════════════════════════════╝"
  echo ""
  for i in "${!QUESTIONS[@]}"; do
    printf "  %2d) %s\n" $((i+1)) "${QUESTIONS[$i]}"
  done
  echo ""
  echo "   a) Run ALL setups"
  echo "   m) Run master-setup.sh first (do this once)"
  echo "   q) Quit"
  echo ""
}

run_question() {
  local num=$(printf "%02d" $1)
  local dir=$(cd "$(dirname "$0")" && pwd)
  echo ""
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo " Setting up Question $1..."
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  bash "$dir/setup-scripts/q${num}-setup.sh"
  echo ""
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo " QUESTION:"
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  cat "$dir/questions/q${num}.txt"
  echo ""
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo " When done, verify with:"
  echo "   bash verify-scripts/q${num}-verify.sh"
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
}

cd "$(dirname "$0")"

while true; do
  show_menu
  read -p "Choose a question (1-16, a, m, q): " choice

  case $choice in
    [1-9])      run_question $choice; break ;;
    1[0-6])     run_question $choice; break ;;
    a|A)
      echo "Running master setup first..."
      bash master-setup.sh
      for i in $(seq 1 16); do
        num=$(printf "%02d" $i)
        bash "setup-scripts/q${num}-setup.sh"
      done
      echo "All questions set up!"
      break
      ;;
    m|M)        bash master-setup.sh ;;
    q|Q)        echo "Good luck on the CKS! 🎯"; exit 0 ;;
    *)          echo "Invalid choice. Try again." ;;
  esac
done
